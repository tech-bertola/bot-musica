import discord
from discord.ext import commands
import yt_dlp

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

ytdl_format_options = {
    "format": "bestaudio/best",
    "noplaylist": True
}

ffmpeg_options = {
    "options": "-vn"
}

ytdl = yt_dlp.YoutubeDL(ytdl_format_options)


@bot.event
async def on_ready():
    print(f"Broxa online como {bot.user}")


@bot.command()
async def play(ctx, *, search):

    if not ctx.author.voice:
        await ctx.send("Você precisa estar em um canal de Broxa.")
        return

    channel = ctx.author.voice.channel

    if ctx.voice_client is None:
        await channel.connect()
    else:
        await ctx.voice_client.move_to(channel)

    info = ytdl.extract_info(f"ytsearch:{search}", download=False)

    url = info["entries"][0]["url"]
    title = info["entries"][0]["title"]

    if ctx.voice_client.is_playing():
        ctx.voice_client.stop()

    source = await discord.FFmpegOpusAudio.from_probe(url, **ffmpeg_options)

    ctx.voice_client.play(source)

    await ctx.send(f"🎵 Tocando: **{title}**")


@bot.command()
async def stop(ctx):
    if ctx.voice_client:
        await ctx.voice_client.disconnect()

bot.run("MTQ4MjQwODM0MTQ2MzYzNDE1Mg.GbMmF3.nDd0H21S261yfCRbplfCymbB4sfkdcTsCX_2HA")